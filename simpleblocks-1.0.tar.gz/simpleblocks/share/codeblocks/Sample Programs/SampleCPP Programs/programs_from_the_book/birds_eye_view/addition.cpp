#include <simplecpp>

main_program{
  int num1, num2, num3;
  cin >> num1;
  cin >> num2;
  num3 = num1 + num2;
  cout << num3;
}

