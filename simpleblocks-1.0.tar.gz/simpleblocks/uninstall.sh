#!/bin/sh

sudo rm -r /usr/share/applications/Simple__Blocks.desktop 
sudo rm -r /usr/share/simpleblocks
sudo rm -r $HOME/Documents/"Sample Programs"

